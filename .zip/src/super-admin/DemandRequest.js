import React from 'react'

function DemandRequest() {
  return (
    <div>DemandRequest</div>
  )
}

export default DemandRequest