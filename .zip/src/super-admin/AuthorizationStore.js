import React from 'react'

function AuthorizationStore() {
  return (
    <div>AuthorizationStore</div>
  )
}

export default AuthorizationStore