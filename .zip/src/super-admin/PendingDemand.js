import React from 'react'

function PendingDemand() {
  return (
    <div>PendingDemand</div>
  )
}

export default PendingDemand