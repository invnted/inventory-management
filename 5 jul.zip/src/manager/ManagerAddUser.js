import React from 'react'

function ManagerAddUser() {
  return (
    <div>ManagerAddUser</div>
  )
}

export default ManagerAddUser